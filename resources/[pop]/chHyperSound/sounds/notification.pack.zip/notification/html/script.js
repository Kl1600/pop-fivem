window.addEventListener('message', function(event) {
    if (event.data.action === 'notify') {
        createNotification(event.data.data);
    }
});

function createNotification(d) {
    const container = document.getElementById('notify-container');
    const id = Math.floor(Math.random() * 10000);
    const duration = d.duration || 5000;
    let html = "";

    if (d.image) {
        // --- STYLE : BIG IMAGE ---
        html = `
        <div class="notif-card big-image" id="notif-${id}">
            <img src="${d.image}" class="img-bg">
            <div class="img-content">
                <div class="img-title">${d.title || ''}</div>
                <div class="img-message">${d.message || ''}</div>
            </div>
            <div class="progress" id="p-${id}"></div>
        </div>`;
    } else if (d.logo) {
        // --- STYLE : LOGO FUSIONNÉ ---
        html = `
        <div class="notif-card logo-style" id="notif-${id}">
            <div class="logo-container">
                <img src="${d.logo}">
            </div>
            <div class="logo-text">
                <div class="logo-title">${d.title || ''}</div>
                <div class="logo-message">${d.message || ''}</div>
            </div>
            <div class="progress" id="p-${id}"></div>
        </div>`;
    }  else if (d.title) {
        // --- STYLE : ADVANCED ---
        // On n'utilise plus de boucle .map() ici pour éviter la répétition
        html = `
        <div class="notif-card advanced" id="notif-${id}">
            <div class="adv-header">
                <div class="adv-title-box">
                    <i class="${d.icon || 'fas fa-user'}"></i> 
                    <span class="adv-title">${d.title}</span>
                </div>
                ${d.badge ? `<span class="adv-badge" style="background:${d.badgeColor || '#e74c3c'}">${d.badge}</span>` : ''}
            </div>
            <div class="adv-body">
                <div class="adv-msg-line">
                    <i class="fas fa-location-dot"></i>
                    <div>${d.message}</div>
                </div>
            </div>
            ${d.sideText ? `<div class="adv-side">${d.sideText}</div>` : ''}
            <div class="progress" id="p-${id}"></div>
        </div>`;
    // Remplacez la partie "STYLE : SIMPLE" dans votre script.js par ceci :
    } else {
        // --- STYLE : SIMPLE ---
        html = `
        <div class="notif-card simple" id="notif-${id}">
            <div class="simple-circle">
                <i class="${d.icon || 'fas fa-dollar-sign'}"></i>
            </div>
            <div class="simple-message">${d.message}</div>
            <div class="progress" id="p-${id}"></div>
        </div>`;
    }

    container.insertAdjacentHTML('afterbegin', html);
    const pBar = document.getElementById(`p-${id}`);
    pBar.style.transition = `linear ${duration}ms`;
    setTimeout(() => { pBar.style.width = '0%'; }, 50);

    setTimeout(() => {
        const el = document.getElementById(`notif-${id}`);
        if (el) {
            el.style.animation = "slideOut 0.3s ease-in forwards";
            setTimeout(() => { el.remove(); }, 300);
        }
    }, duration);
}

// --- TESTS LIVE SERVER ---
if (!window.invokeNative) {
    window.onload = function() {
        // 1. STYLE LOGO (MAZE BANK / PDM)
        createNotification({
            logo: "https://cdn.discordapp.com/attachments/1452696417016614912/1454515082414260466/x-ECrtyV_400x400_1.jpg?ex=69515e3b&is=69500cbb&hm=642a23aac075a42d8b9b558ae21a0db8bdb8bd4d8b341afd46ce754c863b4ad4&", 
            title: "PDM",
            message: "Votre paiement de <span style='color:#2ecc71; font-weight:bold;'>25000$</span> a été envoyé.",
            duration: 500000
        });

        // 2. STYLE BIG IMAGE
        setTimeout(() => {
            createNotification({
                title: "NOUVEAU VÉHICULE",
                message: "La Pfister Meteor est dispo !",
                image: "https://img.gta5-mods.com/q85-w800/images/pfister-meteor-add-on/e81e81-0.png",
                duration: 500000
            });
        }, 1500);

        // 3. STYLE ADVANCED


        createNotification({
            title: "Braquage en cours",
            message: "West Vinewood<br>Showroom Benefactor<br>",
            icon: "fas fa-location-dot",
            badge: "Niveau 2",
            badgeColor: "#e74c3c",
            sideText: "3km",
            duration: 300000
        });

            createNotification({
                message: "Argent reçu : <span style='color:#2ecc71; font-weight:bold;'>1000$</span>",
                duration: 300000
            });
    };
}